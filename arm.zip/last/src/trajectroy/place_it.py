#!/usr/bin/env python3

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg 
import geometry_msgs.msg 
from std_srvs.srv import Empty


moveit_commander.roscpp_initialize(sys.argv)
rospy.init_node('move_group_python_interface_tutorial', anonymous=True)

robot = moveit_commander.RobotCommander()
scene = moveit_commander.PlanningSceneInterface()
group = moveit_commander.MoveGroupCommander("arm_planning_group")
display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory)


def gripper_on():
    # Wait till the srv is available
    rospy.wait_for_service('/arm/vacuum_gripper/on')
          # Create a handle for the calling the srv
    turn_on = rospy.ServiceProxy('/arm/vacuum_gripper/on', Empty)
        # Use this handle just like a normal function and call it
    resp = turn_on()
    return resp


def gripper_off():
    rospy.wait_for_service('/arm/vacuum_gripper/off')
    turn_off = rospy.ServiceProxy('/arm/vacuum_gripper/off', Empty)
    resp = turn_off()
    return resp


while not rospy.is_shutdown():

 group.set_named_target("pick")

 plan1 = group.plan()

 rospy.sleep(5)

 group.go(wait=True)
 gripper_off()


 group.set_named_target("place")

 plan2 = group.plan()

 rospy.sleep(5)

 group.go(wait=True)

 gripper_on()

 

moveit_commander.roscpp_shutdown()