#!/usr/bin/env python3

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg 
import geometry_msgs.msg 
from std_msgs.msg import Bool
from std_srvs.srv import Empty

def gripper_on():
    # Wait till the srv is available
    #rospy.wait_for_service('/vikram/vacuum_gripper/on')
          # Create a handle for the calling the srv
    turn_on = rospy.ServiceProxy('/vikram/vacuum_gripper/on', Empty)
        # Use this handle just like a normal function and call it
    resp = turn_on()
    return resp


def gripper_off():
    #rospy.wait_for_service('/vikram/vacuum_gripper/off')
    turn_off = rospy.ServiceProxy('/vikram/vacuum_gripper/off', Empty)
    resp = turn_off()
    return resp



moveit_commander.roscpp_initialize(sys.argv)
rospy.init_node('move_group_python_interface_tutorial', anonymous=True)

robot = moveit_commander.RobotCommander()
scene = moveit_commander.PlanningSceneInterface()
group = moveit_commander.MoveGroupCommander("arm_planning_group")
group.set_goal_tolerance(0.001)
group.set_planning_time(5.0)
display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory)
while not rospy.is_shutdown():
  group.set_named_target("load")
  plan1 = group.plan()
  group.go(wait=True)
  a = rospy.ServiceProxy('/arm/vacuum_gripper/on', Empty)
  a()
  rospy.sleep(5)


  group.set_named_target("unload")
  plan2 = group.plan()

  group.go(wait=True)
  b = rospy.ServiceProxy('/arm/vacuum_gripper/off', Empty)
  b()
  rospy.sleep(5)
  
  
moveit_commander.roscpp_shutdown()